#include "Option.h"
#include <stdio.h>
void Option()
{
		printf("*************************************************************\n");
        printf("**    CHUONG TRINH QUAN LY HOC VIEN LOP FRESHER EMBEDDED   **\n");
        printf("**      1. Them hoc vien                                   **\n");
        printf("**      2. Liet ke danh sach hoc vien                      **\n");
        printf("**      3. Xoa hoc vien theo ma hoc vien(ID)               **\n");
        printf("**      4. Sap xep theo diem trung binh tang dan(GPA)      **\n");
        printf("**      0. Thoat                                           **\n");
        printf("*************************************************************\n");
        printf("**               Nhap lua chon cua ban                     **\n");
}
